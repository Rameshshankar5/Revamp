package com.revamp.customer.dev;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

@RestController
@RequestMapping("/api/dev")
@Profile("dev") // only enabled when SPRING_PROFILES_ACTIVE=dev
public class DevTokenController {

  @Value("${security.jwt.secret}")
  private String secret;

  @Value("${security.jwt.issuer:customerservice}")
  private String issuer;

  @GetMapping(value = "/token", produces = MediaType.APPLICATION_JSON_VALUE)
  public Map<String, Object> token(
      @RequestParam(defaultValue = "u-1001") String userId,
      @RequestParam(defaultValue = "customer@example.com") String username,
      @RequestParam(defaultValue = "CONSUMER") String role,
      @RequestParam(defaultValue = "86400") long ttl // seconds (1 day)
  ) {
    SecretKey key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    Instant now = Instant.now();
    String jwt = Jwts.builder()
        .issuer(issuer)
        .subject(userId)
        .issuedAt(Date.from(now))
        .expiration(Date.from(now.plusSeconds(ttl)))
        .claim("username", username)
        .claim("role", role)
        .signWith(key)
        .compact();

    return Map.of(
        "token", jwt,
        "user", Map.of("id", userId, "email", username, "role", role)
    );
  }
}
