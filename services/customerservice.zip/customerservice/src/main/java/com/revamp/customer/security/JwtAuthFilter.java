package com.revamp.customer.security;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

  @Value("${security.jwt.secret}")
  private String secret;

  // issuer is optional; do not require() it since authservice might not set it
  @Value("${security.jwt.issuer:}")
  private String issuer;

  @Override
  protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
      throws ServletException, IOException {

    String auth = req.getHeader(HttpHeaders.AUTHORIZATION);
    if (auth == null || !auth.startsWith("Bearer ")) {
      chain.doFilter(req, res);
      return;
    }

    String token = auth.substring(7);

    try {
      // jjwt 0.12.x style: build a SecretKey, verifyWith(...), build(), parseSignedClaims(...)
      SecretKey key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));

      Claims claims = Jwts.parser()
          .verifyWith(key)
          .build()
          .parseSignedClaims(token)
          .getPayload();

      // (optional) only check issuer if configured and present on token
      if (issuer != null && !issuer.isBlank()) {
        String iss = claims.getIssuer();
        if (iss != null && !issuer.equals(iss)) {
          throw new RuntimeException("Invalid issuer");
        }
      }

      Date exp = claims.getExpiration();
      if (exp != null && exp.before(new Date())) {
        throw new RuntimeException("JWT expired");
      }

      String subject = claims.getSubject();
      String username = claims.get("username", String.class);
      String principal = (username != null && !username.isBlank()) ? username : subject;
      if (principal == null || principal.isBlank()) {
        throw new RuntimeException("Missing subject");
      }

      List<GrantedAuthority> authorities = new ArrayList<>();

      String singleRole = claims.get("role", String.class); // e.g., "CONSUMER"
      if (singleRole != null && !singleRole.isBlank()) {
        authorities.add(new SimpleGrantedAuthority(prefixRole(singleRole)));
      }

      @SuppressWarnings("unchecked")
      Collection<String> roles = (Collection<String>) claims.get("roles");
      if (roles != null) {
        for (String r : roles) {
          authorities.add(new SimpleGrantedAuthority(prefixRole(r)));
        }
      }

      @SuppressWarnings("unchecked")
      Collection<String> auths = (Collection<String>) claims.get("authorities");
      if (auths != null) {
        for (String a : auths) {
          authorities.add(new SimpleGrantedAuthority(a.startsWith("ROLE_") ? a : prefixRole(a)));
        }
      }

      var authentication =
          new UsernamePasswordAuthenticationToken(principal, null, authorities);
      authentication.setDetails(claims);

      SecurityContextHolder.getContext().setAuthentication(authentication);
      chain.doFilter(req, res);

    } catch (Exception ex) {
      SecurityContextHolder.clearContext();
      res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
      res.setContentType("application/json");
      res.getWriter().write("{\"status\":401,\"error\":\"Unauthorized\",\"message\":\"Invalid or expired token\"}");
    }
  }

  private static String prefixRole(String role) {
    String r = role.trim().toUpperCase();
    return r.startsWith("ROLE_") ? r : "ROLE_" + r;
  }
}
