package com.revamp.customer.api;

import com.revamp.customer.model.Customer;
import com.revamp.customer.repo.CustomerRepository;
import io.jsonwebtoken.Claims;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/customer")
public class CustomerMeController {

  private final CustomerRepository repo;

  public CustomerMeController(CustomerRepository repo) {
    this.repo = repo;
  }

  // Frontend currently calls /api/customer/customers/me
  // We support that and also /api/customer/me
  @GetMapping({"/customers/me", "/me"})
  public ResponseEntity<?> me() {
    // pull claims the JwtAuthFilter stored
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    if (auth == null || auth.getDetails() == null) {
      return ResponseEntity.status(401).body(err("Unauthorized"));
    }

    Claims claims;
    try {
      claims = (Claims) auth.getDetails();
    } catch (ClassCastException ex) {
      return ResponseEntity.status(401).body(err("Unauthorized"));
    }

    // Prefer a stable id from token: subject (userId) or username/email
    String userId = claims.getSubject();                // e.g., "user-123"
    String username = claims.get("username", String.class); // optional

    // Adjust this lookup to your schema:
    //  - If your Customer has userId -> use findByUserId
    //  - If by email/username -> use the relevant repository method
    Optional<Customer> customerOpt =
        (userId != null && !userId.isBlank())
            ? repo.findByUserId(userId)
            : (username != null && !username.isBlank()
                ? repo.findByEmail(username) // or findByUsername(username)
                : Optional.empty());

    if (customerOpt.isEmpty()) {
      return ResponseEntity.status(404).body(err("Customer not found"));
    }

    Customer c = customerOpt.get();
    // Return the entity or map to a DTO if you prefer
    return ResponseEntity.ok(c);
  }

  private static java.util.Map<String,Object> err(String msg) {
    return java.util.Map.of("status", "error", "message", msg);
  }
}
